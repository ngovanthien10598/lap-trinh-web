<?php
$con = new mysqli("localhost", "root", "", "buoi3");
mysqli_set_charset($con, "utf8");